#nodejs-client-api#
==============

##Clusterpoint Node.js API##

* [Clusterpoint WEB page](https://www.clusterpoint.com)

* [Clusterpoint Documentation page](https://www.clusterpoint.com/docs/)

* [Clusterpoint API library reference and examples](https://www.clusterpoint.com/docs/?page=Reference)

* [Clusterpoint tutorials](https://www.clusterpoint.com/docs/?page=Tutorials)

* [NPM package manager](https://www.npmjs.org/package/cps-api)

##Installation##

Use NPM package manager to install Clusterpoint Node.js API:

`npm install cps-api`

##Support##
Please feel free to contact the maintainer of this package on
support@clusterpoint.com
